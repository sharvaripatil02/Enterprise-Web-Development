import java.io.*;  
import javax.servlet.*;  
import javax.servlet.http.*;  
import java.util.*;
import java.io.File;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import java.io.IOException;
import java.util.HashMap;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParserFactory;
import java.sql.*;

public class DealMatches extends HttpServlet 
{

public String username;
public int cartcount; 

MySqlDataStoreUtilities objSqlDataStore = new MySqlDataStoreUtilities();

public static HashMap<String, ProductCatalog> selectedProducts = new HashMap<String, ProductCatalog>();

ProductCatalog pc = null;

protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, java.io.IOException	{		
		
	PrintWriter out = response.getWriter();		
	
	String docType = "<!doctype html>\n";
		out.println(docType+"<html>"+"<head>"+"<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />"+
			"<title>SmartPortables</title>"+
			"<link rel='stylesheet' href='styles.css' type='text/css' />"+
			"</head>"+"<body>"+
	"<div id='container'>"+
		"<header>"+
			"<h1 style='font-family: blaze'><a href='/'>Smart<span>Portables</span></a></h1>"+				
		"</header>"+
		"<nav>"+
			"<ul>"+	

				"<li><a href='index.html'>Home</a></li>"+
				"</nav>");
			out.println("<table class='table well'>");
				
	try
	{
			HashMap<String, ProductCatalog> allProductsMap = objSqlDataStore.selectProductDetails();
			
			String line = null;
			String category = null;
			
			for(String key : allProductsMap.keySet())
			{				
				pc = new ProductCatalog();
				pc = allProductsMap.get(key);

				if(selectedProducts.size() < 2 && !selectedProducts.containsKey(pc.getId()))
				{					
					BufferedReader reader = new BufferedReader(new FileReader(new File(Constants.DEAL_MATCH_FILEPATH)));
					line = reader.readLine();
					if(line == null)
					{
						out.println("<h3 align='center'>No Offers Found</h3>");
						break;
					}
					else
					{
						do
						{
							if(line.contains(pc.getName()))
							{
								out.println("<h3>"+line+"</h3>");
								out.println("<br>");
								selectedProducts.put(pc.getId(),pc);
								break;
							}
						}while((line= reader.readLine()) != null);
					}
					reader.close();
				}				
			}
			
			
				
			out.println(" </ul>"+
		"</nav>"+

		"<div id='body'>"+
			"<section id='content'>"+
				"<article>"+
					"<h2 align='center'>Deal Matches</h2>"+
				"</article>");
			
			for(String key : selectedProducts.keySet())
			{
				pc = new ProductCatalog();
				pc = selectedProducts.get(key);

			out.println(
			"<tr>"+
			"<td>"+
				"<img src = '"+ pc.getImagepath() +"' width = '250' height = '250' alt = 'phone'>"+
			"</td>"+
			"<td>"+
				"<p><b>Model:</b>"+ pc.getName() +"</p>"+
				"<p><b>Retailer:</b>"+ pc.getRetailer()+ "</p>"+
				"<p><b>Discount:</b>"+ pc.getCondition()+ "</p>"+
				"<p><b>Price:</b>"+ pc.getPrice()+ "</p>"+
			"</td>"+
"<td align='center'>"+
			
					
				"<form class = 'submit-button' method = 'get' action = '/csj/AddToCartServlet'>"+
					"<input type = 'hidden' name = 'hiddenProdID' value = '"+pc.getId()+"'>"+
					"<input type = 'hidden' name = 'hiddenProdName' value = '"+pc.getName()+"'>"+
					"<input type = 'hidden' name = 'hiddenProdPrice' value = '"+pc.getPrice()+"'>"+
					"<input class = 'submit-button' type = 'submit' name = 'laptops' value = 'Add to Cart'>"+
				"</form>"+	

			"<form id='writeReview' class = 'submit-button' method = 'get' action = '/csj/WriteReviews'>"+
                "<input type = 'hidden' name = 'hiddenProdID' value = '"+pc.getId()+"'>"+
                "<input type = 'hidden' name = 'hiddenProdName' value = '"+pc.getName()+"'>"+
                "<input type = 'hidden' name = 'hiddenProdPrice' value = '"+pc.getPrice()+"'>"+
                "<input type = 'hidden' name = 'hiddenProdCateg' value = '"+pc.getCategory()+"'>"+
                "<input type = 'hidden' name = 'hiddenRetailer' value = '"+pc.getRetailer()+"'>"+
                "<input type = 'hidden' name = 'hiddenZip' value = '60616'>"+
                "<input type = 'hidden' name = 'hiddenState' value = 'IL'>"+
                "<input type = 'hidden' name = 'hiddenCity' value = 'Chicago'>"+
                "<input type = 'hidden' name = 'hiddenManfName' value = '"+pc.getManufacturer()+"'>"+
                "<input type = 'hidden' name = 'hiddenManfRebate' value = 'yes'>"+
				"<input type = 'hidden' name = 'hiddenProdCateg' value = 'Speakers'>"+
                "<input class = 'submit-button' type = 'submit' name = 'smartwatch' value = 'Write Review'>"+
				"</form>"+
				
				"<form class = 'submit-button' method = 'get' action = '/csj/ViewReviews'>"+
                "<input type = 'hidden' name = 'hiddenProdID' value = '"+pc.getId()+"'>"+
                "<input class = 'submit-button' type = 'submit' name = 'smartwatch' value = 'View Reviews'>"+
            "</form>"+

			"</td>"+
		"</tr>");			
	
			}		

	}

	

	catch(SQLException e)
	{
		System.out.println("Error - SQLException");
	}
	
	
}
}