import java.io.*;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;

public class AdminServlet extends HttpServlet {

    protected void processPage(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, java.io.IOException {
         response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        // create your filewriter and bufferedreader
        ServletContext sc = request.getSession().getServletContext();
        //BufferedReader buffReader = new BufferedReader(new FileReader(sc.getRealPath("productdetails.txt")));
        HashMap<String,String> product = new HashMap<String,String>();
        String currentLine;
        String docType = 
        "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 "+
        "Transitional//EN\">\n";
        out.println(docType + "<html>"+
            "<head>"+
            "<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />"+
            "<title>Storemanager Page</title>"+
            "<link rel='stylesheet' href='styles.css' type='text/css' />"+
            "</head>"+
            "<body>"+
            "<div id='container'>"+
            "<header>"+
            "<h1><a href='http://localhost/csj/index.html'>Storemanager Panel</a></h1>"+
            "</header>");

        out.println(
            "</table>"+
			"<fieldset>"+
			"<legend><b>Add Product</b></legend>"+
            "<a href='/csj/AddProduct1.html'>Click here to add more Products</a>"+
			
            "<br><br><br><br>"+
			"</fieldset>"+
			
			"<fieldset>"+
			
			"<legend>Update Product</legend>"+
            
			"<form id='updateProduct' action='/csj/UpdateProductServlet' method='post'>"+

			"<label>Product Id </label>"+
            "<input type='number' name='prodID' id='prodID' />"+
			"<br><br>"+
			

			"<label>Product Type </label>"+
				"<select name='product_type'>"+
				"<option value = 'ExternalStorage'>External Storage</option>"+
				"<option value = 'Headphones'>Headphones</option>"+
				"<option value = 'Laptop'>Laptop</option>"+
				"<option value = 'Phone'>Phone</option>"+
				"<option value = 'Accessory'>Accessory</option>"+
				"<option value = 'Speaker'>Speakers</option>"+
				"<option value = 'SmartWatch'>Smart Watch</option>"+
				"</select><br><br>"+
				
			
			
			"<label>Update Column/Field </label>"+
				"<select name='column_name'>"+
				"<option value = 'prodname'>Name</option>"+
				"<option value = 'retailer'>Retailer</option>"+
				"<option value = 'manufacturer'>Manufacturer</option>"+
				"<option value = 'imagepath'>Image Path</option>"+
				"<option value = 'prodcondition'>Product Condition</option>"+
				"<option value = 'sale'>Sale</option>"+
				
				"</select><br><br>"+
			
			"<label>Enter updated value</label>"+
			"<input type='text' name='update_value' id='update_value'/>"+
			"<br><br>"+
			
			
            "<input type='submit' name='Submit' value='Submit' />"+
			"<br><br><br><br>"+

            "</form>"+
			"</fieldset>"+
			
            "<fieldset>"+
           
		   "<legend>Delete Product</legend>"+
            
			"<form id='deleteProduct' action='/csj/DeleteProductServlet' method='post'>"+

			"<label>Product Id </label>"+
            "<input type='number' name='prodID' id='prodID' />"+
			"<br><br>"+
			

			"<label>Product Type </label>"+
				"<select name='product_type'>"+
				"<option value = 'ExternalStorage'>External Storage</option>"+
				"<option value = 'Headphones'>Headphones</option>"+
				"<option value = 'Laptop'>Laptop</option>"+
				"<option value = 'Phone'>Phone</option>"+
				"<option value = 'Accessory'>Accessory</option>"+
				"<option value = 'Speaker'>Speakers</option>"+
				"<option value = 'SmartWatch'>Smart Watch</option>"+
				"</select><br><br>"+
			
            "<input type='submit' name='Submit' value='Submit' />"+

            "</form>"+
			"</fieldset>"+
			"</br></br>"+
			"<fieldset>"+
			"<legend>Inventory Report</legend>"+
			"</br>"+
			"<a href = '/csj/allproducts'>All Products</a>"+
            "</br></br>"+
			"<a href = '/csj/salesmanagerbarchart'>Generate Bar Chart</a>"+
            "</br></br>"+
			"<a href = '/csj/onsaleproducts'>On Sale Products</a>"+
            "</br></br>"+
			"<a href = '/csj/manufacturerrebateproducts'>Manufacturer Rebate Products</a>"+
            "</br></br>"+
			"<fieldset>"+
			"</br></br>"+
			
			"</br></br>"+
			"<fieldset>"+
			"<legend>Sales Report</legend>"+
			"</br>"+
			"<a href = '/csj/allproductssales'>All Products</a>"+
            "</br></br>"+
			"<a href = '/csj/soldproductsbarchart'>Generate Bar Chart</a>"+
            "</br></br>"+
			"<a href = '/csj/dailysaleservlet'>Total Daily Sales</a>"+
            "</br></br>"+
			"<fieldset>"+
			"</br></br>"+
			
            "<a href='/csj/login.html'>Sign Out</a>"+
            "</fieldset>"+
            "<footer>"+
            "<div class='footer-bottom'>"+
            "<p>CSP 595 - Enterprise Web Application - Assignment 1</p>"+
            "</div>"+
            "</footer>"+
            "</div>"+
            "</body>"+
            "</html>");
    } 
    
    /** Handles the HTTP <code>GET</code> method.
    * @param request servlet request
    * @param response servlet response
    */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, java.io.IOException {
        processPage(request, response);
    } 

    /** Handles the HTTP <code>POST</code> method.
    * @param request servlet request
    * @param response servlet response
    */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, java.io.IOException {
        processPage(request, response);
    }
}
