import java.io.*;  
import javax.servlet.*;  
import javax.servlet.http.*;  
import java.util.*;

public class LoginServlet extends HttpServlet {
	
	HashMap<String, Users> hmUsers = null;
	MySqlDataStoreUtilities objSqlDataStore = new MySqlDataStoreUtilities();
	String uname = null,password= null,utype = null;
	boolean flag = false;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		PrintWriter out = response.getWriter();		
		HtmlUtility htmlUtil = new HtmlUtility(request,out);		
		
		htmlUtil.printLoginContent();
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)	throws ServletException, IOException 
	{
		try {

			uname = request.getParameter("username").toLowerCase().trim();
			password = request.getParameter("password");
			utype = request.getParameter("user_type").toLowerCase().trim();
			
			hmUsers = objSqlDataStore.selectUserDetails();
			
			for(String key : hmUsers.keySet())
			{
				
				flag = true;
				if(flag)
				{
					HttpSession session = request.getSession();
					session.setAttribute("username", uname);
					session.setAttribute("usertype", utype);					
					if(uname != null && password != null)
					{
						if(utype.equals("storemanager"))
							response.sendRedirect("/csj/AdminServlet");
						else if(utype.equals("salesman"))
							response.sendRedirect("/csj/SalesmanServlet");
						else if(utype.equals("customer"))
							response.sendRedirect("/csj/index.html");
						
					}	
				}
			}
			
			if(!flag)
			{
				response.setContentType("text/html");
				java.io.PrintWriter out = response.getWriter();
				out.println("<html>");
				out.println("<head>");
				out.println("<title>Login Servlet Result</title>");
				out.println("</head>");
				out.println("<body>");
				out.println("<h2>" + "Login Failed. Incorrect Credentials" + "</h2>");
				out.println("<br/>");
				out.println("<a href='home'> Home Page </a>");
				out.println("<br/>");
				out.println("<a href='login'> Login Page </a>");
				out.println("</body>");
				out.println("</html>");
				out.close();
			}		
		}
		catch(Exception ex)
		{
			System.out.println("LoginServlet- "+ ex.toString());
		}
	}
}
