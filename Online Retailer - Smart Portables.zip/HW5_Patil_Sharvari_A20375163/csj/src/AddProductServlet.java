import java.io.*;  
import javax.servlet.*;  
import javax.servlet.http.*;  
import java.util.*;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.File;
import java.util.HashMap;	
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import java.io.IOException;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;
import javax.xml.parsers.SAXParserFactory;
import java.sql.*;
	
	public class AddProductServlet extends HttpServlet
	{
		public String producttype;
		public String filePath;
		
		
		MySqlDataStoreUtilities objSqlDataStore = new MySqlDataStoreUtilities();
		
		public static HashMap<String, ProductCatalog> hm_prod = new HashMap<String, ProductCatalog>();
		ProductCatalog objProductCatalog = new ProductCatalog();
		
		public void doPost(HttpServletRequest request, HttpServletResponse response)  throws ServletException, IOException {
			try
			{
				response.setContentType("text/html");  
				PrintWriter out = response.getWriter();				
								
				MySqlDataStoreUtilities objSql = new MySqlDataStoreUtilities();	
								
								
				objProductCatalog.setId(request.getParameter("Id"));
				objProductCatalog.setRetailer(request.getParameter("Retailer"));
				objProductCatalog.setManufacturer(request.getParameter("Manufacturer"));
				objProductCatalog.setManufacturerRebate(Float.valueOf(request.getParameter("ManufacturerRebate")));
				objProductCatalog.setQuantity(Integer.valueOf(request.getParameter("Quantity")));
				objProductCatalog.setProdCondition(request.getParameter("ProductCondition"));
				objProductCatalog.setSale(request.getParameter("Sale"));
				objProductCatalog.setName(request.getParameter("name"));
				objProductCatalog.setImagepath(request.getParameter("Image"));
				objProductCatalog.setRetailerDiscount(Float.valueOf(request.getParameter("discount")));
				objProductCatalog.setPrice(Float.valueOf(request.getParameter("price")));				
		
				objProductCatalog.setCategory(request.getParameter("category"));
				
				producttype = request.getParameter("category");
				
					if(producttype.equalsIgnoreCase("phone"))
					{
						filePath = Constants.PhoneXML;
						objSql.insertProductDetails(objProductCatalog);
					}
					else if(producttype.equalsIgnoreCase("smartwatches"))
					{
						filePath = Constants.SmartWatchesXML;
						objSql.insertProductDetails(objProductCatalog);
					}
					else if(producttype.equalsIgnoreCase("accessories"))
					{
						filePath = Constants.AccessoryXML;
						objSql.insertProductDetails(objProductCatalog);
					}
					else if(producttype.equalsIgnoreCase("laptop"))
					{
						filePath = Constants.LaptopXML;
						objSql.insertProductDetails(objProductCatalog);
					}
					else if(producttype.equalsIgnoreCase("externalstorage"))
					{
						filePath = Constants.ExternalStorageXML;
						objSql.insertProductDetails(objProductCatalog);
					}			
					else if(producttype.equalsIgnoreCase("speakers"))
					{
						filePath = Constants.SpeakersXML;
						objSql.insertProductDetails(objProductCatalog);
					}
					
					else if(producttype.equalsIgnoreCase("headphones"))
					{
						filePath = Constants.HeadphonesXML;
						objSql.insertProductDetails(objProductCatalog);
					}

					SAXProductHandler saxHandler = new SAXProductHandler();
					try
					{
						hm_prod = saxHandler.readDataFromXML(filePath);					
						WriteXML();	
						
						/*for (ProductCatalog pc : hm_prod.values()) 
						{
							objSqlDataStore.insertProductDetails(pc);
						}*/
						
					}
					catch(SAXException e)
					{
						
					}
					catch(ParserConfigurationException e)
					{
						
					}
					catch(TransformerException e)
					{
						
					}
					out.println(
			"<html>"+
			"<body>"+
			"<h3>Product is successfully added</a></h3>"+
			"<a href='/csj/AdminServlet'> Admin Page </a>"
			);
				
			}
			catch (SQLException ex)
			{
				
			}
			
		}
			
			public void WriteXML() throws ParserConfigurationException, TransformerFactoryConfigurationError, TransformerException
			{
				DocumentBuilder builder = null;
				builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
				Document document = builder.newDocument();
				
				Element root = document.createElement("ProductCatalog");
								
				for(String key : hm_prod.keySet())
				{				 
					ProductCatalog value = hm_prod.get(key);				
					
					Element newNode = document.createElement(producttype);
					
					
					Element nodeID = document.createElement("id");					
					Element nodeImage = document.createElement("image");
					Element nodeName = document.createElement("name");
					Element nodePrice = document.createElement("price");
					Element nodeRetailer = document.createElement("retailer");
					Element nodeManufacturer = document.createElement("manufacturer");
					Element nodeManufacturerRebate = document.createElement("MANUFACTURER_REBATE");
					Element nodeQuantity = document.createElement("QUANTITY");
					Element nodeDiscount = document.createElement("RETAILER_DISCOUNT");
					Element nodeSale = document.createElement("SALE");
					Element nodeCategory = document.createElement("CATEGORY");
					Element nodeProdCond = document.createElement("PRODCONDITION");
					
					
					
					 
					nodeID.setTextContent(value.getId());
					nodeName.setTextContent(value.getName());
					nodePrice.setTextContent(String.valueOf(value.getPrice()));
					nodeImage.setTextContent(value.getImagepath());
					nodeRetailer.setTextContent(value.getRetailer());
					nodeManufacturer.setTextContent(value.getManufacturer());
					nodeManufacturerRebate.setTextContent(String.valueOf(value.getManufacturerRebate()));
					nodeQuantity.setTextContent(String.valueOf(value.getQuantity()));
					nodeDiscount.setTextContent(String.valueOf(value.getRetailerDiscount()));
					nodeSale.setTextContent(value.getSale());
					nodeCategory.setTextContent(value.getCategory());
					nodeProdCond.setTextContent(value.getProdCondition());				
					

					newNode.appendChild(nodeID);
					newNode.appendChild(nodeImage);
					newNode.appendChild(nodeName);
					newNode.appendChild(nodePrice);
					newNode.appendChild(nodeRetailer);					
					newNode.appendChild(nodeManufacturer);
					newNode.appendChild(nodeManufacturerRebate);
					newNode.appendChild(nodeQuantity);
					newNode.appendChild(nodeDiscount);
					newNode.appendChild(nodeSale);
					newNode.appendChild(nodeCategory);
					newNode.appendChild(nodeProdCond);
					
					
					root.appendChild(newNode);
					
				}
				
				
					Element newNode = document.createElement(producttype);
					
					Element nodeID = document.createElement("id");					
					Element nodeImage = document.createElement("image");
					Element nodeName = document.createElement("name");
					Element nodePrice = document.createElement("price");
					Element nodeRetailer = document.createElement("retailer");
					Element nodeManufacturer = document.createElement("manufacturer");
					Element nodeManufacturerRebate = document.createElement("MANUFACTURER_REBATE");
					Element nodeQuantity = document.createElement("QUANTITY");
					Element nodeDiscount = document.createElement("RETAILER_DISCOUNT");
					Element nodeSale = document.createElement("SALE");
					Element nodeCategory= document.createElement("CATEGORY");
					Element nodeProdCond = document.createElement("PRODCONDITION");
					
					
					
					 
					nodeID.setTextContent(objProductCatalog.getId());
					nodeName.setTextContent(objProductCatalog.getName());
					nodePrice.setTextContent(String.valueOf(objProductCatalog.getPrice()));
					nodeImage.setTextContent(objProductCatalog.getImagepath());
					nodeRetailer.setTextContent(objProductCatalog.getRetailer());
					nodeManufacturer.setTextContent(objProductCatalog.getManufacturer());
					nodeManufacturerRebate.setTextContent(String.valueOf(objProductCatalog.getManufacturerRebate()));
					nodeQuantity.setTextContent(String.valueOf(objProductCatalog.getQuantity()));
					nodeDiscount.setTextContent(String.valueOf(objProductCatalog.getRetailerDiscount()));
					nodeSale.setTextContent(objProductCatalog.getSale());
					nodeCategory.setTextContent(objProductCatalog.getCategory());
					nodeProdCond.setTextContent(objProductCatalog.getProdCondition());				
					

					newNode.appendChild(nodeID);
					newNode.appendChild(nodeImage);
					newNode.appendChild(nodeName);
					newNode.appendChild(nodePrice);
					newNode.appendChild(nodeRetailer);					
					newNode.appendChild(nodeManufacturer);
					newNode.appendChild(nodeManufacturerRebate);
					newNode.appendChild(nodeQuantity);
					newNode.appendChild(nodeDiscount);
					newNode.appendChild(nodeSale);
					newNode.appendChild(nodeCategory);
					newNode.appendChild(nodeProdCond);
					
					
					root.appendChild(newNode);
				
				document.appendChild(root);
				
				Transformer transformer = TransformerFactory.newInstance().newTransformer();
				Source source = new DOMSource(document);
				File file = new File(filePath);
				Result result = new StreamResult(file);
				transformer.setOutputProperty(OutputKeys.INDENT, "yes");
				transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
				transformer.transform(source, result);				
			}
	}