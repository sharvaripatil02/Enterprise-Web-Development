import java.io.*;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;
import java.util.Date;
import java.sql.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;


public class AddToCartServlet extends HttpServlet {

    protected void processPage(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, java.io.IOException {
         response.setContentType("text/html;charset=UTF-8");
		 
		 MySqlDataStoreUtilities objorders = new MySqlDataStoreUtilities();
		 
        PrintWriter out = response.getWriter();
        String prodID = request.getParameter("hiddenProdID");
        String prodName = request.getParameter("hiddenProdName");
        String prodPrice = request.getParameter("hiddenProdPrice");
		float prodPricedb = Float.parseFloat(prodPrice);
		int prodquantity = 1;		
		
		String prodID_Accessory = request.getParameter("hiddenProdID_accessory");
		String prodName_Accessory = request.getParameter("hiddenProdName_accessory");
		String prodPrice_Accessory = request.getParameter("hiddenProdPrice_accessory");

		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
		Date date = new Date();
		String orderdate = dateFormat.format(date);
		
		
		
		// orders MYSQL Database
		try
		{
			objorders.insertOrder(prodID,prodName,prodPricedb,prodquantity,orderdate);
		}
		catch(SQLException e)
		{
			System.out.println("Error - SQLException");
		}
		
		
        // create map to store
        // create list one and store values
		
		
	   List<String> valSetOne = new ArrayList<String>();
        valSetOne.add(prodID);
        valSetOne.add(prodName);
        valSetOne.add(prodPrice);


        cart shoppingCart;
        HttpSession session = request.getSession();
        shoppingCart = (cart) session.getAttribute("cart");
        if(shoppingCart == null){
          shoppingCart = new cart();
          session.setAttribute("cart", shoppingCart);
        }

        shoppingCart.addToCart(prodID, valSetOne);
        session.setAttribute("cart", shoppingCart);


        HashMap<String, List<String>> items = shoppingCart.getCartItems();
        String docType = 
        "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 "+
        "Transitional//EN\">\n";
        out.println(docType + "<html>"+
            "<head>"+
            "<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />"+
            "<title>Smart Portables</title>"+
            "<link rel='stylesheet' href='styles.css' type='text/css' />"+
			"<link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css'>"+
			"<script src='https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js'></script>"+
			"<script src='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js'></script>"+

            "</head>"+
            "<body>"+
            "<div id='container'>"+
            "<header>"+
            "<h1><a href='http://localhost/csj/index.html'>Smart<span>Portables</span></a></h1>"+
            "<h2>Cart Page</h2>"+
            "</header>"+
            "<table>"+
            "<tr>"+
            "<th>ProductID</th>"+
            "<th>Product Name</th>"+
            "<th>Price</th>"+
            //"<th>Category</th>"+
            "<th></th>"+
            "</tr>");
                for (HashMap.Entry<String, List<String>> entry : items.entrySet()) {
                String key = entry.getKey();
                List<String> values = entry.getValue();
                out.println("<tr>");
                out.println("<td>"+values.get(0)+"</td>");
                out.println("<td>"+values.get(1)+"</td>");
                out.println("<td>"+values.get(2)+"</td>");
                //out.println("<td>"+values.get(3)+"</td>");
                out.println("<td><form method = 'get' action = '/csj/DeleteCartItemServlet'><input type='hidden' name='hiddenDelProdID' value='"+key+"'><input class = 'submit-button' type = 'submit' name = 'deleteButton' value = 'Delete'></form></td>");
                out.println("</tr>");
                }
             out.println(
            "</table>"+
            "<a href='index.html'>Click here to add more Products to Cart</a>"+
            "</br></br>"+
            "<form class = 'submit-button' method = 'get' action = '/csj/Checkout'>"+
            "<input class = 'submit-button' type = 'submit' name = 'Checkout' value = 'Proceed To Checkout'>"+
            "</form>"+
			
"<div class='container'>"+
  "<h3>Accessories</h3>"+  
  "<div id='myCarousel' class='carousel slide' data-ride='carousel'>"+
   

	"<ol class='carousel-indicators'>"+
      "<li data-target='#myCarousel' data-slide-to='0' class='active'></li>"+
      "<li data-target='#myCarousel' data-slide-to='1'></li>"+
      "<li data-target='#myCarousel' data-slide-to='2'></li>"+
    "</ol>"+

    
    "<div class='carousel-inner'>"+
      "<div class='item active'>"+
        "<img src='/csj/images/accessory/mousepad.jpg' alt='Mouse Pad' style='width:20%;'>"+
		        "<div class='carousel-caption'>"+
          "<a href='/csj/accessory'>"+
		  "<button type='button' class='btn btn-default'>Details</button></a>"+
        "</div>"+
      "</div>"+

      "<div class='item'>"+
        "<img src='/csj/images/accessory/headphone1.jpg' alt='Headphone' style='width:20%;'>"+
		"<div class='carousel-caption'>"+
          "<a href='/csj/accessory'>"+
		  "<button type='button' class='btn btn-default'>Details</button></a>"+
        "</div>"+
      "</div>"+
    
      "<div class='item'>"+
        "<img src='/csj/images/accessory/chargecable.jpg' alt='ChargeCable' style='width:20%;'>"+
		"<div class='carousel-caption'>"+
          "<a href='/csj/accessory'>"+
		  "<button type='button' class='btn btn-default'>Details</button></a>"+
        "</div>"+
      "</div>"+
    "</div>"+

    "<a class='left carousel-control' href='#myCarousel' data-slide='prev'>"+
      "<span class='glyphicon glyphicon-chevron-left'></span>"+
      "<span class='sr-only'>Previous</span>"+
    "</a>"+
    "<a class='right carousel-control' href='#myCarousel' data-slide='next'>"+
      "<span class='glyphicon glyphicon-chevron-right'></span>"+
      "<span class='sr-only'>Next</span>"+
    "</a>"+
  "</div>"+
"</div>"+

			  "</body>"+
            "</html>");
        }
    
    /** Handles the HTTP <code>GET</code> method.
    * @param request servlet request
    * @param response servlet response
    */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, java.io.IOException {
        processPage(request, response);
    } 

    /** Handles the HTTP <code>POST</code> method.
    * @param request servlet request
    * @param response servlet response
    */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, java.io.IOException {
        processPage(request, response);
    }
}
