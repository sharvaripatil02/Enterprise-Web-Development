/*
 * LoginServlet.java
 *
 */
 
import java.io.*;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;

public class Checkout extends HttpServlet {
	
	MySqlDataStoreUtilities objSqlDataStore = new MySqlDataStoreUtilities();

    protected void processPage(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, java.io.IOException {
		
		String creditCard = request.getParameter("cardnumber");
		
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        HttpSession session = request.getSession();
        cart shoppingCart;
        shoppingCart = (cart) session.getAttribute("cart");
        session.setAttribute("cart", shoppingCart);
        shoppingCart = (cart) session.getAttribute("cart");
        List<String> productIDs = new ArrayList<String>();
        HashMap<String, List<String>> items = shoppingCart.getCartItems();
        Double total = 0.00;
        String docType = 
        "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 "+
        "Transitional//EN\">\n";
        out.println(docType + "<html>"+
                    "<head>"+
                    "<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />"+
                    "<title>Smart Portables</title>"+
                    "<link rel='stylesheet' href='styles.css' type='text/css' />"+
                    "</head>"+
                    "<body>"+
                    "<div id='container'>"+
                    "<header>"+
                    "<h1><a href='http://localhost/csj/index.html'>Smart<span>Portables</span></a></h1>"+
                    "</header>"+
                    "<h1>Place Order</h1>"+                         
                    " <form method='get' action='/csj/SubmitOrderMessage.html'>"+
                    "<fieldset>"+
                    "<legend>Product information:</legend>"+
                    "<table>"+
                    "<tr>"+
                    "<th>ProductID</th>"+
                    "<th>Product Name</th>"+
                    "<th>Price</th>"+
                "</tr>");
                for (HashMap.Entry<String, List<String>> entry : items.entrySet()) 
                {
                    String key = entry.getKey();
                    List<String> values = entry.getValue();

                    out.println("<tr>");
                    out.println("<td>ProductID: <input type='text' name='productID' value= '"+values.get(0)+"' readonly> </td>");
                    out.println("<td>Product Name: <input type='text' name='productName' value= '"+values.get(1)+"' readonly> </td>");
                    out.println("<td>Price: <input type='text' name='productPrice' value= '"+values.get(2)+"' readonly> </td>");
                    out.println("</tr>");
                    total = total + Double.parseDouble(values.get(2));
                    productIDs.add(values.get(0));
					productIDs.add(values.get(1));
					productIDs.add(values.get(2));
					productIDs.add(":");
                }
                String idList = productIDs.toString();
				//out.println("Product ids:"+idList);
				
				//Write orders to file
				ServletContext sc = request.getSession().getServletContext();
				File filename = new File(sc.getRealPath("customerorders.txt"));
				FileWriter filestream = new FileWriter(filename,true);
				BufferedWriter buffWriter = new BufferedWriter(filestream);
				buffWriter.write(idList);
				buffWriter.write("\n");
				buffWriter.close();
				filestream.close();
				
                String prodIDS = idList.substring(1, idList.length() - 1).replace(", ", ",");
			out.println(
            "<tr>"+
            "<td colspan ='3'>Total : "+total+"</td>"+
            "</tr>"+
            "</table>"+
            "</fieldset>"+
            "<fieldset>"+
            "<legend>Personal information:</legend>"+
            "<table>"+
            
            "<tr>"+
            "<td> CreditCard: </td>"+
            "<td> <input type='password' maxlength='16' name='cardnumber'> </td>"+
            "</tr>"+
            "</table>"+
            "<br><br>"+
            "<input type='hidden' name='hiddenOrderTotal' value='"+total+"'>"+
            "<input type='hidden' name='hiddenProductIDs' value='"+prodIDS+"'>"+

            "<input class = 'submit-button' type = 'submit' name = 'orderButton' value = 'Place Order'>"+
            "</fieldset>"+
            "</form>"+
            "<footer>"+
            "<div class='footer-bottom'>"+
            "<p>CSP 595 - Enterprise Web Application</p>"+
            "</div>"+
            "</footer>"+
            "</div>"+
            "</body>"+
            "</html>");
    } 
    
    /** Handles the HTTP <code>GET</code> method.
    * @param request servlet request
    * @param response servlet response
    */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, java.io.IOException {
        processPage(request, response);
    } 

    /** Handles the HTTP <code>POST</code> method.
    * @param request servlet request
    * @param response servlet response
    */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, java.io.IOException {
        processPage(request, response);
    }
}
