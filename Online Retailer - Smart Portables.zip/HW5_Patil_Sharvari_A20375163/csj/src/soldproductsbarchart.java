import java.io.*; 
import java.sql.*; 
import javax.servlet.*;  
import javax.servlet.http.*; 

import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.chart.ChartUtilities;

public class soldproductsbarchart extends HttpServlet {
   
   
   protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
		{		
			try
			{
				PrintWriter out = response.getWriter();		
				 Class.forName( "com.mysql.jdbc.Driver" );
      Connection connect = DriverManager.getConnection( 
         "jdbc:mysql://localhost:3306/SMARTPORTABLES" ,     
         "root",     
         "admin");
      
      Statement statement = connect.createStatement( );
      ResultSet resultSet = statement.executeQuery("select * from orders" );
      DefaultCategoryDataset dataset = new DefaultCategoryDataset( );
      
      while( resultSet.next( )) 
	  {
         dataset.addValue( resultSet.getInt( "price" ),
         resultSet.getString( "prodname" ) ,
         "" );
      }
      
	 
	  
      JFreeChart barChart = ChartFactory.createBarChart(
         "Total Product Sales", 
         "Product", "Price", 
         dataset,PlotOrientation.HORIZONTAL, 
         true, true, false);

      int w = 1000;    
      int h = 1000;    
      File barchartimg = new File( "C:/apache-tomcat-7.0.34/webapps/csj/images/SoldProductChart.jpeg" );
      ChartUtilities.saveChartAsJPEG( barchartimg , barChart , w , h );
	 out.println("<html>");
					out.println("<body>");
					out.println("<img src='/csj/images/SoldProductChart.jpeg'>");
					out.println("</br></br>"+	
								"<a href = '/csj/AdminServlet'> Back to Store Manager Page</a>");
					out.println("</body>");
					out.println("</html>");	
				
			}
			catch(Exception ex)
			{
				
			}
		}
		
}