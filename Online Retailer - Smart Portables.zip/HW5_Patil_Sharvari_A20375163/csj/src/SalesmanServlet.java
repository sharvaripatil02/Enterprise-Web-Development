import java.io.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.Date;
import java.util.Random;
import java.util.Calendar;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

public class SalesmanServlet extends HttpServlet {
    
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
            
            PrintWriter out = response.getWriter();


            String docType = "<!doctype html>\n";
            out.println(docType +
            "<html>"+
            "<head>"+
            "<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />"+
            "<title>Smart Portables</title>"+
            "<link rel='stylesheet' href='styles.css' type='text/css' />"+
            "</head>"+
             "<body>"+
            "<div id='container'>"+
            "<header>"+
            "<h1><a href='/'>Salesman Panel</a></h1>"+
            "</header>"+
            "<nav>"+
            "<ul>"+
            "<li class='start selected'><a href='login.html'>Sign Out</a></li>"+
            "</ul>"+
            "</nav>"+
            "<div id='body'>"+
            "<section id='content'>"+
            "<article>");
          
            out.println("</article>"+
                "</section>"+
				"<br>"+
                "<a href='/csj/registration.html'>Create New Customers</a>"+
            "<br><br>"+
                "<a href='/csj/index.html'>Create New Order</a>"+
            
			"</br></br>"+
			"<a href='/csj/SalesmanOrders'>Customers Orders</a>"+
            
           "<footer>"+
            "<div class='footer-content'>"+
            "<ul>"+
            "<li><h4>Quick Links</h4></li>"+
            "<li><a href='login.html'>Login</a></li>"+
            "</ul>"+
            "<div class='clear'></div>"+
            "</div>"+
            "<div class='footer-bottom'>"+
            "<p>CSP 595 - Enterprise Web Application - Assignment 1</p>"+
            "</div>"+
            "</footer>"+
            "</div>"+
            "</body>"+
            "</html>");

        }
}