/*
 * LoginServlet.java
 *
 */
 
import java.io.*;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;


public class SalesmanOrders extends HttpServlet {
   
    protected Map users = new HashMap();
	String[] temp;
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, java.io.IOException {
		PrintWriter out = response.getWriter();
		ServletContext sc =request.getSession().getServletContext();
        BufferedReader buffReader = new BufferedReader(new FileReader(sc.getRealPath("customerorders.txt")));

        HashMap<String,String> product = new HashMap<String,String>();
        String currentLine;
        String docType = 
        "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 "+
        "Transitional//EN\">\n";
        out.println(docType + "<html>"+
            "<head>"+
            "<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />"+
            "<title>Salesman Panel</title>"+
            "<link rel='stylesheet' href='styles.css' type='text/css' />"+
            "</head>"+
            "<body>"+
            "<div id='container'>"+
            "<header>"+
            "<h1><a href='http://localhost/csj/index.html'>Salesman<span>Panel</span></a></h1>"+
            "</header>"+
            "<table>"+
            "<tr>"+
            "<th>Orders</th>"+
            "</tr>");
        while((currentLine =buffReader.readLine())!=null)
        {
            //String [] prods = currentLine.split("]");
            String [] prodVars = currentLine.split(":");
			String [] prodorder = prodVars[0].split(",");
            out.println("<tr>");
            out.println("<td>"+prodVars[0]+"</td>");
            out.println("<td>"+prodVars[1]+"</td>");
            out.println("<td>"+prodVars[2]+"</td>");

            out.println("</tr>");
			
        }

        buffReader.close();
		out.println(
            "</table>"+
            "</br></br>"+
            "<form class = 'submit-button' method = 'get' action = '/csj/SalesmanServlet'>"+
            "<input class = 'submit-button' type = 'submit' name = 'Smart_Portables' value = 'Back to Salesman Panel'>"+
            "</form>"+
            "</div>"+
            "</body>"+
            "</html>");
    }
    
    /** Handles the HTTP <code>GET</code> method.
    * @param request servlet request
    * @param response servlet response
    */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, java.io.IOException {
        processRequest(request, response);
    } 

    /** Handles the HTTP <code>POST</code> method.
    * @param request servlet request
    * @param response servlet response
    */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, java.io.IOException {
        processRequest(request, response);
    }
}
