public class Constants {

	public Constants()
	{
		
	}
	
	public static final String STORE_MANAGER = "Store Manager";
	public static final String SALESMAN = "Salesman";
	public static final String CUSTOMER = "Customer";
	public static final String PhoneXML = "C:/apache-tomcat-7.0.34/webapps/csj/WEB-INF/Phone.xml";
	public static final String SmartWatchesXML = "C:/apache-tomcat-7.0.34/webapps/csj/WEB-INF/SmartWatches.xml";
	public static final String AccessoryXML = "C:/apache-tomcat-7.0.34/webapps/csj/WEB-INF/Accessory.xml";
	public static final String LaptopXML = "C:/apache-tomcat-7.0.34/webapps/csj/WEB-INF/Laptop.xml";
	public static final String ExternalStorageXML = "C:/apache-tomcat-7.0.34/webapps/csj/WEB-INF/ExternalStorage.xml";
	public static final String SpeakersXML = "C:/apache-tomcat-7.0.34/webapps/csj/WEB-INF/Speakers.xml";
	public static final String HeadphonesXML = "C:/apache-tomcat-7.0.34/webapps/csj/WEB-INF/Headphones.xml";
	public static final String UserDetailFile = "C:/Users/Nishu.user-PC/workspace/Test/WebContent/WEB-INF/UserDetails.txt";
	
	
	public static final String LOGIN_CONTENT_FILEPATH = "C:/apache-tomcat-7.0.34/webapps/csj/login.html";
	public static final String REGISTER_CONTENT_FILEPATH = "C:/apache-tomcat-7.0.34/webapps/csj/registration.html";
	public static final String DEAL_MATCH_FILEPATH = "C:/apache-tomcat-7.0.34/webapps/csj/DealMatches.txt";
}
