import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.HashMap;
import java.sql.*;
import java.util.Date;

public class MySqlDataStoreUtilities
{
	Connection conn = null;
	HashMap<String, Users> hmUsers = null;
	HashMap<String, ProductCatalog> hmProductCatalog = new HashMap<String, ProductCatalog>();
	Users objUser = null;
	PreparedStatement pst = null;
	ResultSet rs = null;
	ProductCatalog pc = null;
	Statement stmt = null;
	
	public MySqlDataStoreUtilities()
	{
		
	}
	
	public HashMap<String, Users> selectUserDetails() throws SQLException
	{
		try
		{
			objUser = new Users();
			hmUsers = new HashMap<String, Users>();
			
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/SMARTPORTABLES","root","admin");
			stmt = conn.createStatement();			
			String selectQuery = "SELECT * FROM USERS";
			rs = stmt.executeQuery(selectQuery);
			
			while(rs.next())
			{
				objUser.setuserId(rs.getString("userid"));
				objUser.setPassword(rs.getString("password"));
				objUser.setUsertype(rs.getString("usertype"));
				objUser.setFirstName(rs.getString("firstname"));
				objUser.setLastName(rs.getString("lastname"));
				objUser.setPhone(rs.getString("phone"));
				objUser.setAddress(rs.getString("address"));
				objUser.setCity(rs.getString("city"));
				objUser.setState(rs.getString("state"));
				objUser.setCountry(rs.getString("country"));
				objUser.setZipcode(rs.getString("zipcode"));
				
				hmUsers.put(rs.getString("userid"), objUser);
			}
			rs.close();
			stmt.close();
			conn.close();
		}
		catch(SQLException se)
		{	//Handle errors for JDBC
			se.printStackTrace();
		}
		catch(Exception e)
		{	//Handle errors for Class.forName
			e.printStackTrace();
		}
		finally
		{
			try
			{
				if(stmt!=null)
                stmt.close();
			}
			catch(SQLException se2)
			{
				
			}
			
			try
			{
				if(conn!=null)
                conn.close();
			}
			catch(SQLException se)
			{
				se.printStackTrace();
			}
		}
		return hmUsers;		
	}
	
	public void insertUserDetails(Users user)throws SQLException
	{
		try
		{
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/SMARTPORTABLES","root","admin");
			String insertQuery = "INSERT INTO USERS(userid,password,usertype,firstname,lastname,phone,address,city,state,country,zipcode) " + "VALUES (?,?,?,?,?,?,?,?,?,?,?);";
			
			pst = conn.prepareStatement(insertQuery);
			
			pst.setString(1,user.getuserId());
			pst.setString(2,user.getPassword());
			pst.setString(3,user.getUsertype());
			pst.setString(4,user.getFirstName());
			pst.setString(5,user.getLastName());
			pst.setString(6,user.getPhone());
			pst.setString(7,user.getAddress());
			pst.setString(8,user.getCity());
			pst.setString(9,user.getState());
			pst.setString(10,user.getCountry());
			pst.setString(11,user.getZipcode());
		
			pst.execute();
			
			pst.close();
			conn.close();
		}
		catch(SQLException se)
		{	//Handle errors for JDBC
			se.printStackTrace();
		}
		catch(Exception e)
		{	//Handle errors for Class.forName
			e.printStackTrace();
		}
		finally
		{
			try
			{
				if(pst!=null)
                pst.close();
			}
			catch(SQLException se2)
			{
				
			}
			
			try
			{
				if(conn!=null)
                conn.close();
			}
			catch(SQLException se)
			{
				se.printStackTrace();
			}
		}
	}

	// Product entry in database
	
	
	public void insertProductDetails(ProductCatalog prod)throws SQLException
	{
		try
		{
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/SMARTPORTABLES","root","admin");
			String insertQuery = "INSERT INTO PRODUCTS(id,prodname,price,retailer,prodcondition,manufacturerRebate,category,quantity,sale,imagepath)" + "VALUES (?,?,?,?,?,?,?,?,?,?);";
			
			pst = conn.prepareStatement(insertQuery);
			
			pst.setString(1,prod.getId());
			pst.setString(2,prod.getName());
			pst.setFloat(3,prod.getPrice());
			pst.setString(4,prod.getRetailer());
			pst.setString(5,prod.getProdCondition());
			pst.setFloat(6,prod.getManufacturerRebate());
			pst.setString(7,prod.getCategory());
			pst.setInt(8,prod.getQuantity());
			pst.setString(9,prod.getSale());
			pst.setString(10,prod.getImagepath());
			pst.execute();
			
			pst.close();
			conn.close();
		}
		catch(SQLException se)
		{	//Handle errors for JDBC
			se.printStackTrace();
		}
		catch(Exception e)
		{	//Handle errors for Class.forName
			e.printStackTrace();
		}
		finally
		{
			try
			{
				if(pst!=null)
                pst.close();
			}
			catch(SQLException se2)
			{
				
			}
			
			try
			{
				if(conn!=null)
                conn.close();
			}
			catch(SQLException se)
			{
				se.printStackTrace();
			}
		}
	}
	
	//Delete Product
	
	public void deleteProductDetails(int productID, String category) throws SQLException {
		try 
		{			
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/SMARTPORTABLES", "root", "admin");
			stmt = conn.createStatement();
			
			System.out.println("%%%%%%"+ productID+category);
			
			String deleteQuery;
			deleteQuery = "DELETE from products WHERE id = "+productID+" AND category like '"+category+"'";
			
			System.out.println("%%%%%%" + deleteQuery);
							
			stmt.executeUpdate(deleteQuery);
						
			stmt.close();
			conn.close();
		} catch (SQLException se) { // Handle errors for JDBC
			se.printStackTrace();
		} catch (Exception e) { // Handle errors for Class.forName
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null)
					stmt.close();
			} catch (SQLException se2) {
			}

			try {
				if (conn != null)
					conn.close();
			} catch (SQLException se) {
				se.printStackTrace();
			}
		}
	}
	
	// Update Product
	
	public void updateProductDetails(int productID, String category, String column_name, String updated_val) throws SQLException {
		try 
		{			
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/SMARTPORTABLES", "root", "admin");
			stmt = conn.createStatement();
						
			String updateQuery;
			updateQuery = "UPDATE products SET "+column_name+"='"+updated_val+"' WHERE id="+productID+" AND category like '"+category+"'";

			stmt.executeUpdate(updateQuery);
						
			stmt.close();
			conn.close();
		} catch (SQLException se) { // Handle errors for JDBC
			se.printStackTrace();
		} catch (Exception e) { // Handle errors for Class.forName
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null)
					stmt.close();
			} catch (SQLException se2) {
			}

			try {
				if (conn != null)
					conn.close();
			} catch (SQLException se) {
				se.printStackTrace();
			}
		}
	}
	
	
	//View Products
	public HashMap<String, ProductCatalog> selectProductDetails() throws SQLException {
		try {
			hmProductCatalog = new HashMap<String, ProductCatalog>();
			ProductCatalog pc = null;
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/SMARTPORTABLES?autoconnect=true&useSSL=false", "root", "admin");
			stmt = conn.createStatement();
			String selectQuery;

			selectQuery = "SELECT * FROM products";
			
			rs = stmt.executeQuery(selectQuery);

			while (rs.next()) {
				pc = new ProductCatalog();

				pc.setId(rs.getString("id"));
				pc.setName(rs.getString("prodname"));
				pc.setPrice(rs.getFloat("price"));
				pc.setCondition(rs.getString("prodcondition"));
				pc.setRetailer(rs.getString("retailer"));
				pc.setManufacturerRebate(rs.getFloat("manufacturerRebate"));
				pc.setCategory(rs.getString("category"));
				pc.setQuantity(rs.getInt("quantity"));
				pc.setSale(rs.getString("sale"));
				pc.setImagepath(rs.getString("imagepath"));

				hmProductCatalog.put(pc.getId(), pc);
			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException se) { // Handle errors for JDBC
			se.printStackTrace();
		} catch (Exception e) { // Handle errors for Class.forName
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null)
					stmt.close();
			} catch (SQLException se2) {

			}

			try {
				if (conn != null)
					conn.close();
			} catch (SQLException se) {
				se.printStackTrace();
			}
		}
		return hmProductCatalog;
	}
	
	
	public void insertOrder(String pcid,String pcname,float pcprice,int pcquantity,String orderdate)throws SQLException
	{
		try
		{
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/SMARTPORTABLES","root","admin");
			String insertQuery = "INSERT INTO ORDERS(id,prodname,price,quantity,orderdate)" + "VALUES (?,?,?,?,?);";
			
			pst = conn.prepareStatement(insertQuery);
			
			pst.setString(1,pcid);
			pst.setString(2,pcname);
			pst.setFloat(3,pcprice);
			pst.setInt(4,pcquantity);
			pst.setString(5,orderdate);
			
			pst.execute();
			
			pst.close();
			conn.close();
		}
		catch(SQLException se)
		{	//Handle errors for JDBC
			se.printStackTrace();
		}
		catch(Exception e)
		{	//Handle errors for Class.forName
			e.printStackTrace();
		}
		finally
		{
			try
			{
				if(pst!=null)
                pst.close();
			}
			catch(SQLException se2)
			{
				
			}
			
			try
			{
				if(conn!=null)
                conn.close();
			}
			catch(SQLException se)
			{
				se.printStackTrace();
			}
		}
	}
}
	
	