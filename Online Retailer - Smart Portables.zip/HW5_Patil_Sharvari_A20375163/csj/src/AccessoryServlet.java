import java.io.*;  
import javax.servlet.*;  
import javax.servlet.http.*;  
import java.util.*;
import java.io.File;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import java.io.IOException;
import java.util.HashMap;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParserFactory;
import java.sql.*;

public class AccessoryServlet extends HttpServlet 
{

public String username;
public int cartcount; 

MySqlDataStoreUtilities objSqlDataStore = new MySqlDataStoreUtilities();

public static HashMap<String, ProductCatalog> hm = new HashMap<String, ProductCatalog>();

protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, java.io.IOException	{		
		
	PrintWriter out = response.getWriter();		

	/*if((request.getSession().getAttribute("cartcount")) == null)
	{
		HttpSession session=request.getSession();
		session.setAttribute("cartcount",0);
	}
	
	if((request.getSession().getAttribute("username")) == null)
	{
		HttpSession session=request.getSession();
		session.setAttribute("username","");
	}
	
	ServletContext objServletContext = request.getSession().getServletContext();
	username = request.getSession().getAttribute("username").toString();
	cartcount = (Integer)request.getSession().getAttribute("cartcount");*/
	
	
	SAXProductHandler saxHandler = new SAXProductHandler();
	try
	{
		hm = saxHandler.readDataFromXML(Constants.AccessoryXML);
		for (ProductCatalog pc : hm.values()) 
		{
			objSqlDataStore.insertProductDetails(pc);
		}
	}
	catch(SAXException e)
	{
		System.out.println("Error - SAXException");
	}
	catch(ParserConfigurationException e)
	{
		System.out.println("Error - ParserConfigurationException");
	}
	catch(SQLException e)
	{
		System.out.println("Error - SQLException");
	}
		
		
	String docType = "<!doctype html>\n";
		out.println(docType+"<html>"+"<head>"+"<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />"+
			"<title>SmartPortables</title>"+
			"<link rel='stylesheet' href='styles.css' type='text/css' />"+
			"</head>"+"<body>"+
	"<div id='container'>"+
		"<header>"+
			"<h1 style='font-family: blaze'><a href='/'>Smart<span>Portables</span></a></h1>"+				
		"</header>"+
		"<nav>"+
			"<ul>"+	
				"<li><a href='index.html'>Home</a></li>");
				
out.println(" </ul>"+
		"</nav>"+

		"<div id='body'>"+
			"<section id='content'>"+
				"<article>"+
					"<h2 align='center'>Welcome</h2>"+
				"</article>"+
				"<article class='expanded'>"+					
					"<table>"+
					"<tr>"+
					"<th colspan='3'>"+
					"<h2 align='center'>List of Accessories</h2>"+
					"</th>"+
					"</tr>");
	
	for (ProductCatalog pc : hm.values()) 
	{
		// checks for null
		if (pc != null) 
		{
			
			out.println("<tr>"+
			
			"<td>"+
				"<img src = '"+ pc.getImagepath() +"' width = '250' height = '250' alt = 'phone'>"+
			"</td>"+
			"<td>"+
				"<p><b>Model:</b>"+ pc.getName() +"</p>"+
				"<p><b>Retailer:</b>"+ pc.getRetailer()+ "</p>"+
				"<p><b>Discount:</b>"+ pc.getCondition()+ "</p>"+
				"<p><b>Price:</b>"+ pc.getPrice()+ "</p>"+
			"</td>"+
			"<td align='center'>"+
			
					
				"<form class = 'submit-button' method = 'get' action = '/csj/AddToCartServlet'>"+
					"<input type = 'hidden' name = 'hiddenProdID' value = '"+pc.getId()+"'>"+
					"<input type = 'hidden' name = 'hiddenProdName' value = '"+pc.getName()+"'>"+
					"<input type = 'hidden' name = 'hiddenProdPrice' value = '"+pc.getPrice()+"'>"+
					"<input class = 'submit-button' type = 'submit' name = 'laptops' value = 'Add to Cart'>"+
				"</form>"+			
				
			    "<form id='writeReview' class = 'submit-button' method = 'get' action = '/csj/WriteReviews'>"+
                "<input type = 'hidden' name = 'hiddenProdID' value = '"+pc.getId()+"'>"+
                "<input type = 'hidden' name = 'hiddenProdName' value = '"+pc.getName()+"'>"+
                "<input type = 'hidden' name = 'hiddenProdPrice' value = '"+pc.getPrice()+"'>"+
                "<input type = 'hidden' name = 'hiddenProdCateg' value = '"+pc.getCategory()+"'>"+
                "<input type = 'hidden' name = 'hiddenRetailer' value = '"+pc.getRetailer()+"'>"+
                "<input type = 'hidden' name = 'hiddenZip' value = '60616'>"+
                "<input type = 'hidden' name = 'hiddenState' value = 'IL'>"+
                "<input type = 'hidden' name = 'hiddenCity' value = 'Chicago'>"+
                "<input type = 'hidden' name = 'hiddenManfName' value = '"+pc.getManufacturer()+"'>"+
                "<input type = 'hidden' name = 'hiddenManfRebate' value = 'yes'>"+
				"<input type = 'hidden' name = 'hiddenProdCateg' value = 'Accessory'>"+
                "<input class = 'submit-button' type = 'submit' name = 'smartwatch' value = 'Write Review'>"+
				"</form>"+
				
				"<form class = 'submit-button' method = 'get' action = '/csj/ViewReviews'>"+
                "<input type = 'hidden' name = 'hiddenProdID' value = '"+pc.getId()+"'>"+
                "<input class = 'submit-button' type = 'submit' name = 'smartwatch' value = 'View Reviews'>"+
                "</form>"+

			"</td>"+
		"</tr>");			
		}		
	}
		
		out.println("</table>"+
				"</article>"+
			"</section>"+
			"<aside class='sidebar'>"+
				 "<ul>"+	
					"<li>"+
						"<h4>Navigation</h4>"+
						"<ul>"+				
					"<li><a href='index.html'>Home Page</a></li>"+
					"<li><a href='/csj/smartwatches'>Smart Watches</a></li>"+
					"<li><a href='/csj/speakers'>Speakers</a></li>"+
					"<li><a href='/csj/headphones'>Headphones</a></li>"+
					"<li><a href='/csj/externalstorage'>External Storage</a></li>"+
					"<li><a href='/csj/accessory'>Accessories</a></li>"+
					"</ul>"+
					"</li>"+
					"<li>"+
						"<h4>About us</h4>"+
						"<ul>"+
							"<li class='text'>"+
								"<p style='margin: 0;'>Smart Portables</p>"+
							"</li>"+
						"</ul>"+
					"</li>"+			
				"</ul>"+	
			" </aside>"+
			"<div class='clear'></div>"+
		"</div>"+
		
"<footer>"+
	"<div class='footer-content'>"+
		"<ul class='endfooter'>"+
			"<li><h4>Contact us</h4></li>"+
			"<li><a href = mailto: 'customerservice@smartportables.com'</a>customerservice@smartportables.com</li>"+
		"</ul>"+		
		"<div class='clear'></div>"+
	"</div>"+	
" </footer>"+
"</div>"+
"</body>"+
"</html>");	
	}
}